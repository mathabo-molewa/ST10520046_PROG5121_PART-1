package com.mycompany.chatapplication;

// Import Scanner to read user input
import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        
        // Create Scanner object to get input from user
        Scanner input = new Scanner(System.in);
        
        // Create Login object to use its methods
        Login login = new Login();
        
        // REGISTRATION SECTION
        
        System.out.println("=== USER REGISTRATION ===");
        
        String username;
        
        // Keep asking for username until it is correct
        while (true) {
            System.out.print("Enter a username: ");
            username = input.nextLine();
            
            // Check if username is valid
            if (login.checkUserName(username)) {
                System.out.println("Username successfully captured");
                break; // exit loop if correct
            } else {
                // Show error if username is wrong
                System.out.println("Username is not correctly formatted; "
                        + "please ensure that it contains an underscore");
            }
        }
        
        // Ask user for password
        System.out.print("Enter a password: ");
        String password = input.nextLine();
        
        // Ask user for phone number
        System.out.print("Enter your South African phone number (+27...): ");
        String phone = input.nextLine();
        
        // Register the user and store message
        String response = login.registerUser(username, password, phone);
        
        // Show registration result
        System.out.println(response);
        
        
        // LOGIN SECTION
        
        System.out.println("\n=== USER LOGIN ===");
        
        // Ask for username
        System.out.print("Enter your username: ");
        String loginUsername = input.nextLine();
        
        // Ask for password
        System.out.print("Enter your password: ");
        String loginPassword = input.nextLine();
       
        // Check if login details are correct
        boolean loggedIn = login.loginUser(loginUsername, loginPassword);
        
        // Get login message
        String loginMessage = login.returnLoginStatus(loggedIn);
        
        // Show login result
        System.out.println(loginMessage);
        
        // Close scanner to save memory
        input.close();
    }
}